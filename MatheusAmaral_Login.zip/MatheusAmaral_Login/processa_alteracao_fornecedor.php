<?php
session_start();
require 'conexao.php';

// Verifica se usuário tem permissão de administrador
if ($_SESSION['perfil'] != 1) {
    echo "<script>alert('Acesso negado!'); window.location.href='principal.php';</script>";
    exit();
}

// Verifica se recebeu o ID do fornecedor
if (empty($_POST['id_fornecedor'])) {
    echo "<script>alert('ID do fornecedor não informado!'); window.history.back();</script>";
    exit();
}

// Recebe os dados do formulário e faz trim para tirar espaços extras
$id_fornecedor = $_POST['id_fornecedor'];
$nome_fornecedor = trim($_POST['nome_fornecedor'] ?? '');
$endereco_fornecedor = trim($_POST['endereco_fornecedor'] ?? '');
$telefone_fornecedor = trim($_POST['telefone_fornecedor'] ?? '');
$email_fornecedor = trim($_POST['email_fornecedor'] ?? '');
$contato_fornecedor = trim($_POST['contato_fornecedor'] ?? '');
$id_funcionario_registro = trim($_POST['id_funcionario_registro'] ?? '');

// Valida se os campos obrigatórios estão preenchidos
if (empty($nome_fornecedor) || empty($endereco_fornecedor) || empty($telefone_fornecedor) || empty($email_fornecedor) || empty($contato_fornecedor)) {
    echo "<script>alert('Por favor, preencha todos os campos obrigatórios!'); window.history.back();</script>";
    exit();
}

try {
    // Prepara o update
    $sql = "UPDATE fornecedor SET
        nome_fornecedor = :nome_fornecedor,
        endereco_fornecedor = :endereco_fornecedor,
        telefone_fornecedor = :telefone_fornecedor,
        email_fornecedor = :email_fornecedor,
        contato_fornecedor = :contato_fornecedor,
        id_funcionario_registro = :id_funcionario_registro
        WHERE id_fornecedor = :id_fornecedor";

    $stmt = $pdo->prepare($sql);

    // Faz o bind dos parâmetros
    $stmt->bindParam(':nome_fornecedor', $nome_fornecedor);
    $stmt->bindParam(':endereco', $endereco_fornecedor);
    $stmt->bindParam(':telefone', $telefone_fornecedor);
    $stmt->bindParam(':email', $email_fornecedor);
    $stmt->bindParam(':contato', $contato_fornecedor);
    $stmt->bindParam(':id_funcionario_registro', $id_funcionario_registro);
    $stmt->bindParam(':id_fornecedor', $id_fornecedor, PDO::PARAM_INT);

    // Executa o update
    if ($stmt->execute()) {
        echo "<script>alert('Fornecedor alterado com sucesso!'); window.location.href='buscar_fornecedor.php';</script>";
    } else {
        echo "<script>alert('Erro ao alterar fornecedor!'); window.history.back();</script>";
    }
} catch (PDOException $e) {
    echo "<script>alert('Erro no banco de dados: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
}
?>
